package com.example.auto_cat_feeder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
