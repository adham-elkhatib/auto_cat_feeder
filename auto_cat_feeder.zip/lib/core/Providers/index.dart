import 'FB Firestore/fbfirestore.provider.dart';

abstract class DataProvider {
  static const defaultProvider = FirestoreProvider;
}
