enum QueryOperator {
  equals,
  notEquals,
  greater,
  greaterOrEqual,
  less,
  lessOrEqual,
  isNull,
}
